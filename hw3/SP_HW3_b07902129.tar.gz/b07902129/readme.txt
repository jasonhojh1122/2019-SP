Installation and Usage
    
    To compile all the required code
    $ make

    To comiple into debug mode (more descriptive information is shown)
    $ make debug

    To comiple into gdb debug mode
    $ make gdb

    To delete all the compiled files
    $ make clean

    To run main
    $ ./main

    To run hw3
    $ ./hw3 [P] [Q] [Task] [QCount]
